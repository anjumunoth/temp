import { Directive, ElementRef, HostListener, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[appBgColor]',
  standalone: false
})
export class BgColorDirective implements OnInit {
 @Input() appBgColor: string;
 @Input() myBorder: string;
 @HostListener('mouseenter') onMouseEnter() {
  this.elementRef.nativeElement.style.backgroundColor = 'yellow';
  this.elementRef.nativeElement.style.color = 'white';
 }
 @HostListener('mouseleave') onMouseLeave() {
  this.elementRef.nativeElement.style.backgroundColor = 'red';
  this.elementRef.nativeElement.style.color = 'white';
 }
  constructor(private elementRef: ElementRef) { 
    this.appBgColor= "red";
    elementRef.nativeElement.style.backgroundColor = 'red';
    elementRef.nativeElement.style.color = 'white';
    this.myBorder="";
  }
ngOnInit(){
  this.elementRef.nativeElement.style.backgroundColorc = this.appBgColor;
  console.log(this.myBorder)
  if(this.myBorder)
    this.elementRef.nativeElement.style.border=this.myBorder;
}
}

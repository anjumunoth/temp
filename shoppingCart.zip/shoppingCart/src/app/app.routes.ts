import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { SearchProductsComponent } from './search-products/search-products.component';

export const routes: Routes = [
    {path:"home",component:HomeComponent},
    {path:"search",component:SearchProductsComponent},
    {path:"",component:HomeComponent}
];

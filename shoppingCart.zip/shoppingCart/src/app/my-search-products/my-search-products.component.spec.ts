import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MySearchProductsComponent } from './my-search-products.component';

describe('MySearchProductsComponent', () => {
  let component: MySearchProductsComponent;
  let fixture: ComponentFixture<MySearchProductsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MySearchProductsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MySearchProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

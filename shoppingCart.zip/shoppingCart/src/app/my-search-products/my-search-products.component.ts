import { Component } from '@angular/core';

@Component({
  selector: 'app-my-search-products',
  standalone: false,
  templateUrl: './my-search-products.component.html',
  styleUrl: './my-search-products.component.css'
})
export class MySearchProductsComponent {

}

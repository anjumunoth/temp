import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mySearch',
  standalone: false
})
export class MySearchPipe implements PipeTransform {

  transform(value: any[], searchText:string,fieldName:string): any[] {
    
     if (searchText == "" )
    return value;
  if (fieldName=="")
    return value;

  var filteredArr = value.filter(element => {
    if (element[fieldName].toString().toUpperCase().includes(searchText.toUpperCase())) {
      return element;
    }
  }
  );
  return filteredArr;
  }

}

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { provideRouter, RouterModule } from '@angular/router';
import { routes } from './app.routes';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { ProductDisplayComponent } from './product-display/product-display.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { CartComponent } from './cart/cart.component';
import { SearchProductsComponent } from './search-products/search-products.component';
import { BgColorDirective } from './bg-color.directive';
import { DirectiveExamplesComponent } from "./directive-examples/directive-examples.component";
import { TwoWayDataBindingExampleComponent } from './two-way-data-binding-example/two-way-data-binding-example.component';
import { EditProductComponent } from './edit-product/edit-product.component';
import { MySearchPipe } from './my-search.pipe';
import { MySearchProductsComponent } from './my-search-products/my-search-products.component';
import { CommonModule } from '@angular/common';
import { MenuComponent } from './menu/menu.component';

 
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    ProductDisplayComponent,
    AddToCartComponent,
    CartComponent,
    SearchProductsComponent,
    BgColorDirective,
    DirectiveExamplesComponent,
    TwoWayDataBindingExampleComponent,
    EditProductComponent,
    MySearchPipe,
    MySearchProductsComponent,
    MenuComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    RouterModule.forRoot(routes)
],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
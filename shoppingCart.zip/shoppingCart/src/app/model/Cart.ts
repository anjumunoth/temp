import { Products } from "./Products";

export class Cart extends Products {
    quantitySelected: number;
    constructor(productId: number, productName: string, imageUrl: string, description: string, premium: number, quantity: number, quantitySelected: number, insurerCover: string) {
        super(productId, productName, imageUrl, description, premium, quantity, insurerCover);
        this.quantitySelected = quantitySelected;


    }
}
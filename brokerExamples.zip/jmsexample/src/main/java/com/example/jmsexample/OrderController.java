package com.example.jmsexample;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

    private final OrderGateway orderGateway;

    public OrderController(OrderGateway orderGateway) {
        this.orderGateway = orderGateway;
    }

    @PostMapping("/orders")
    public String placeOrder(@RequestBody OrderRequest request) {
        orderGateway.sendOrder(request);
        return "Order sent to queue!";
    }

//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<OrderResponse> handleException(Exception ex) {
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                .body(new OrderResponse("FAILED", "Invalid order request"));
//    }
}

package com.example.jmsexample;

import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.stereotype.Component;

@Component
public class OrderProcessor {

    @ServiceActivator(inputChannel = "orderProcessingChannel")
    public void process(OrderMessage message) {
        System.out.println("Processing Order: " + message);
    }
}

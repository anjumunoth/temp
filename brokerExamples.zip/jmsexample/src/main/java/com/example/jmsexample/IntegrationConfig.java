package com.example.jmsexample;

import jakarta.jms.ConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.jms.dsl.Jms;

@Configuration
public class IntegrationConfig {
    @Value("${app.queue.name}")
    private String queueName;

    private final ConnectionFactory connectionFactory;

    public IntegrationConfig(ConnectionFactory connectionFactory) {
        this.connectionFactory = connectionFactory;
//        this.queueName = queueName;
    }


    // Outbound (Producer → Queue)
    @Bean
    public IntegrationFlow jmsOutboundFlow() {
        return IntegrationFlow.from("jmsOutboundChannel")
                .handle(Jms.outboundAdapter(connectionFactory)
                        .destination(queueName))
                .get();
    }

    // Inbound (Queue → Consumer)
    @Bean
    public IntegrationFlow jmsInboundFlow() {
        return IntegrationFlow
                .from(Jms.messageDrivenChannelAdapter(connectionFactory)
                        .destination(queueName))
                .channel("orderProcessingChannel")
                .get();
    }
}

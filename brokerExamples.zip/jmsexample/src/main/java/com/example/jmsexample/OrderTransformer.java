package com.example.jmsexample;

import org.springframework.integration.annotation.Transformer;
import org.springframework.stereotype.Component;

@Component
public class OrderTransformer {

    @Transformer(inputChannel = "orderInputChannel",
            outputChannel = "jmsOutboundChannel")
    public OrderMessage transform(OrderRequest request) {
        return new OrderMessage(
                request.getOrderId(),
                request.getItem(),
                request.getQuantity(),
                System.currentTimeMillis()
        );
    }
}

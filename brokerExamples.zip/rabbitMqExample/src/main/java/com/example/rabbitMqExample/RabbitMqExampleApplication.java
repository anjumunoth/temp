package com.example.rabbitMqExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitMqExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(RabbitMqExampleApplication.class, args);
	}

}

/*
Run: for starting rabbitmq

docker compose up -d

RabbitMQ UI:

http://localhost:15672

Login:

guest / guest

Post request to localhost:8080/orders
 */

/*
Test request
curl -X POST http://localhost:8080/orders \
  -H "Content-Type: application/json" \
  -d '{
    "orderId": "ORD-1001",
    "customerName": "Anju",
    "amount": 2500
  }'

Expected API response:

"Order published to RabbitMQ"

Console output should show something like:

Received order request: com.example.orderintegration.dto.OrderRequest@...
Transformed order event: com.example.orderintegration.dto.OrderEvent@...
Received from RabbitMQ: ORD-1001, customer=Anju, amount=2500.0, status=CREATED, source=order-service


13) Invalid request example
curl -X POST http://localhost:8080/orders \
  -H "Content-Type: application/json" \
  -d '{
    "orderId": "",
    "customerName": "",
    "amount": 0
  }'

Expected response:

{
  "orderId": "orderId is required",
  "customerName": "customerName is required",
  "amount": "amount must be greater than 0"
}
14) How the flow works

Real flow:

REST Controller
   ->
OrderGateway
   ->
ordersInputChannel
   ->
transform OrderRequest to OrderEvent
   ->
AMQP outbound adapter
   ->
RabbitMQ Exchange
   ->
Queue
   ->
RabbitListener Consumer
 */

package com.example.helloWorldWithXml;

public class PrintService {
    public void print(String message) {
        System.out.println("Processed Message: " + message);
    }
}
package com.example.helloWorldWithXml;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;

@SpringBootApplication
@ImportResource("classpath:integration-context.xml")
public class HelloWorldAppWithXml {
    public static void main(String[] args) {
        SpringApplication.run(HelloWorldAppWithXml.class,args);
    }
    @Bean
    CommandLineRunner runner(MessageChannel inputChannel)
    {
        return args ->  inputChannel.send(
            MessageBuilder.withPayload("Hello Spring Integration").build()
        );
    }
}

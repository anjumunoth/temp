package com.example.adapterExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdapterExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}

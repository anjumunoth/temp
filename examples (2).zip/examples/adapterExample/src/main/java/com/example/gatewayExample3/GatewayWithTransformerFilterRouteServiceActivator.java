package com.example.gatewayExample3;

/*
Flow:

Gateway receives input
Transformer trims and normalizes text
Filter rejects empty input
Router decides route:
if payload contains "laptop" → electronics flow
otherwise → general flow
Service Activator builds the final response
 */

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.messaging.MessageHandlingException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@SpringBootApplication
public class GatewayWithTransformerFilterRouteServiceActivator {

    public static void main(String[] args) {
        SpringApplication.run(GatewayWithTransformerFilterRouteServiceActivator.class, args);
    }

    @MessagingGateway
    public interface OrderGateway {

        @Gateway(requestChannel = "orderInputChannel", replyTimeout = 5000)
        String process(String input);
    }

    @Bean
    public IntegrationFlow mainFlow(OrderTransformer orderTransformer, OrderRouter orderRouter) {
        return IntegrationFlow.from("orderInputChannel")
                .log(msg -> "Input: " + msg.getPayload())
                .transform(orderTransformer, "normalize")
                .log(msg -> "After transform: " + msg.getPayload())
                .filter(String.class,
                        payload -> !payload.isBlank(),
                        spec -> spec.throwExceptionOnRejection(true))
                .log(msg -> "After filter: " + msg.getPayload())
                .route(orderRouter, "route")
                .get();
    }

    @Bean
    public IntegrationFlow electronicsFlow(OrderService orderService) {
        return IntegrationFlow.from("electronicsChannel")
                .handle(orderService, "processElectronicsOrder")
                .get();
    }

    @Bean
    public IntegrationFlow generalFlow(OrderService orderService) {
        return IntegrationFlow.from("generalChannel")
                .handle(orderService, "processGeneralOrder")
                .get();
    }

    @Bean
    CommandLineRunner run(OrderGateway orderGateway) {
        return args -> {
            process(orderGateway, "  laptop ");
            process(orderGateway, " book ");
            process(orderGateway, "   ");
        };
    }

    private static void process(OrderGateway gateway, String input) {
        try {
            System.out.println("Input: [" + input + "]");
            System.out.println("Output: " + gateway.process(input));
        } catch (Exception e) {
            System.out.println("Input: [" + input + "]");
            System.out.println("Error: " + e.getMessage());
        }
    }
}

@Service
class OrderService {

    public String processElectronicsOrder(String item) {
        return "Electronics order processed for item: " + item;
    }

    public String processGeneralOrder(String item) {
        return "General order processed for item: " + item;
    }
}





package com.example.gatewayExample4;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
public class OrderRouter {

    public String route(OrderRequest request) {
        if (request.getItem().contains("laptop") || request.getItem().contains("mobile")) {
            return "electronicsChannel";
        }
        return "generalChannel";
    }
}


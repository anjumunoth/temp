package com.example.gatewayExample4;

import org.springframework.stereotype.Component;

@Component
public class OrderTransformer {

    public OrderRequest normalize(OrderRequest request) {
        if (request == null) {
            return new OrderRequest("", 0);
        }

        String normalizedItem = request.getItem() == null ? "" : request.getItem().trim().toLowerCase();
        return new OrderRequest(normalizedItem, request.getQuantity());
    }
}

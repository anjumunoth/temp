package com.example.adapterExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdapterExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdapterExampleApplication.class, args);
	}

}

package com.example.gatewayExample4;

/*
Dependency to be added :
<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-web</artifactId>

</dependency>
Internal flow
REST controller receives JSON request
Controller calls gateway
Transformer normalizes the request
Filter validates quantity and item
Router decides category
Service Activator processes correct business path
Response comes back to REST API
 */


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.stereotype.Component;

@SpringBootApplication
public class GatewayWithRest {
    public static void main(String[] args) {
        SpringApplication.run(GatewayWithRest.class, args);
    }
}

/*
src/main/java/com/example/restintegration
├── RestIntegrationApplication.java
├── config
│   └── IntegrationConfig.java
├── controller
│   └── OrderController.java
├── dto
│   ├── OrderRequest.java
│   └── OrderResponse.java
├── gateway
│   └── OrderGateway.java
├── integration
│   ├── OrderRouter.java
│   └── OrderTransformer.java
└── service
    └── OrderService.java
 */



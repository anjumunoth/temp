package com.example.gatewayExample2;


import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@SpringBootApplication
public class GatewayWithTransformerLogServiceActivator {

    public static void main(String[] args) {
        SpringApplication.run(GatewayWithTransformerLogServiceActivator.class, args);
    }

    @MessagingGateway(defaultRequestChannel = "inputChannel")
    public interface HelloGateway {
        String process(String name);
    }

    @Bean
    public IntegrationFlow helloFlow(NameTransformer nameTransformer, HelloService helloService) {
        return IntegrationFlow.from("inputChannel")
                .log(msg -> "Before transform: " + msg.getPayload())
                .transform(nameTransformer, "normalize")
                .log(msg -> "After transform: " + msg.getPayload())
                .handle(helloService, "generateGreeting")
                .log(msg -> "Final response: " + msg.getPayload())
                .get();
    }

    @Bean
    CommandLineRunner run(HelloGateway helloGateway) {
        return args -> {
            String response1 = helloGateway.process("anju");
            String response2 = helloGateway.process("SPRING");
            String response3 = helloGateway.process("");

            System.out.println(response1);
            System.out.println(response2);
            System.out.println(response3);
        };
    }
}

@Service
class HelloService {

    public String generateGreeting(String name) {
        return "Hello, " + name + "! Message processed successfully.";
    }
}


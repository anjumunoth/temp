package com.example.gatewayExample;


import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.stereotype.Service;

@SpringBootApplication
public class GatewayDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(GatewayDemoApplication.class, args);
    }

    @MessagingGateway(defaultRequestChannel = "helloInputChannel")
    public interface HelloGateway {
        String sayHello(String name);
    }

    @Bean
    public IntegrationFlow helloFlow() {
        return IntegrationFlow.from("helloInputChannel")
                .transform(String.class, name -> "Hello, " + name + "! Welcome to Spring Integration.")
                .get();
    }

    @Bean
    CommandLineRunner run(HelloService helloService) {
        return args -> helloService.greet();
    }
}

@Service
class HelloService {

    private final GatewayDemoApplication.HelloGateway helloGateway;

    HelloService(GatewayDemoApplication.HelloGateway helloGateway) {
        this.helloGateway = helloGateway;
    }

    public void greet() {
        String message = helloGateway.sayHello("Anju");
        System.out.println(message);
    }
}

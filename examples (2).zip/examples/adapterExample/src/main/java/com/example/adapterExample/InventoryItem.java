package com.example.adapterExample;

public class InventoryItem {
    private String sku;
    private int quantity;
    // Getters, Setters, Constructor

    public InventoryItem(String sku) {
        this.sku = sku;
    }

    public InventoryItem(String sku, int quantity) {
        this.sku = sku;
        this.quantity = quantity;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}

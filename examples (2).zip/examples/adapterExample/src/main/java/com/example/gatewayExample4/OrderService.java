package com.example.gatewayExample4;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    public OrderResponse processElectronicsOrder(OrderRequest request) {
        return new OrderResponse(
                "SUCCESS",
                "Electronics order accepted for item: " + request.getItem() + ", quantity: " + request.getQuantity()
        );
    }

    public OrderResponse processGeneralOrder(OrderRequest request) {
        return new OrderResponse(
                "SUCCESS",
                "General order accepted for item: " + request.getItem() + ", quantity: " + request.getQuantity()
        );
    }
}


package com.example.gatewayExample3;

import org.springframework.stereotype.Component;

@Component
public class OrderTransformer {

    public String normalize(String input) {
        return input == null ? "" : input.trim().toLowerCase();
    }
}

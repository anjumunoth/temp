package com.example.adapterExample;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.Pollers;
import org.springframework.integration.file.FileHeaders;
import org.springframework.integration.file.dsl.Files;
import org.springframework.integration.file.filters.AcceptOnceFileListFilter;
import org.springframework.integration.file.transformer.FileToStringTransformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessagingException;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


@Configuration
@EnableIntegration
public class IntegrationConfig {

    private final String INPUT_DIR = "C:/inventory/inbox";
    private final String ARCHIVE_DIR = "C:/inventory/processed";
    private final String ERROR_DIR = "C:/inventory/errors";

    // --- 1. THE MAIN FLOW ---
    @Bean
    public IntegrationFlow inventoryFileFlow() {
        return IntegrationFlow.from(
                        Files.inboundAdapter(new File(INPUT_DIR))
                                .patternFilter("*.csv")
//                                .filter(new AcceptOnceFileListFilter<>())
                                ,

                        e -> e.poller(Pollers.fixedDelay(10000)
                                // FEATURE: Pick ONLY 1 file per poll cycle
                                .maxMessagesPerPoll(1)
                                // FEATURE: Route any errors in this flow to this channel
                                .errorChannel("inventoryErrorChannel"))
                )
                .transform(new FileToStringTransformer())
                .transform(this::parseCsv)
                .handle(inventoryService(), "updateStock")
                // If we reach here, it was successful -> Move to Archive
                .handle(m -> archiveFile(m,ARCHIVE_DIR))
                .get();
    }

    // --- 2. THE ERROR HANDLING FLOW ---
    @Bean
    public IntegrationFlow errorHandlingFlow() {
        return IntegrationFlow.from("inventoryErrorChannel")
                .handle(errorMessage -> {
                    // Extract the original message that failed
                    Message<?> failedMessage = ((MessagingException) errorMessage.getPayload()).getFailedMessage();
                    System.out.println("Failed messsage"+failedMessage.getPayload());
                    // Logic: Log the error and move the bad file to the ERROR folder
                    System.err.println("CRITICAL ERROR: " + errorMessage.getPayload());

                    archiveFile(failedMessage, ERROR_DIR);
                })
                .get();
    }
    // Logic to convert CSV rows to a List of Objects
    private List<InventoryItem> parseCsv(String csvContent) {
        List<InventoryItem> resultList=Arrays.stream(csvContent.split("\n"))
                .map(line -> {
                    String[] parts = line.split(",");
                    return new InventoryItem(parts[0], Integer.parseInt(parts[1].trim()));
                })
                .collect(Collectors.toList());
        System.out.println("Output pf parseCsv : "+resultList);
        return resultList;
    }
    // Reusable helper to move files
    private void archiveFile(Message<?> message, String targetDir) {
        File file = (File) message.getHeaders().get(FileHeaders.ORIGINAL_FILE);
        if (file != null) {
            file.renameTo(new File(targetDir + "/" + file.getName()));
            System.out.println("File moved to: " + targetDir);
        }
    }
    interface InventoryService {
        /*
        What it is: This is a Functional Interface. In Java, an interface with exactly one abstract method is "functional," meaning it can be implemented using a Lambda expression (->).
The Role: In Spring Integration, this represents the "Business Logic" layer. It defines what should happen to the data once it has been fetched and transformed from the CSV file.
         */

        List<InventoryItem> updateStock(List<InventoryItem> items);
    }
    @Bean
    public InventoryService inventoryService() {
        /*
        @Bean: This tells Spring to instantiate this service and keep it in its "toolbox" (the Application Context). Other parts of the app (like the IntegrationFlow) can now "ask" Spring for this service.
The Lambda (items -> ...): This is the actual implementation of the updateStock method.
items: This represents the List<InventoryItem> produced by the previous step in your integration flow.
items.forEach(...): It loops through every item in that list.
System.out.println(...): In a real-world app, this is where you would call a Repository (like inventoryRepository.save(item)) to actually update a Database (MySQL, PostgreSQL, etc.). Here, it's just simulating the action by printing to the console.
         */
        return items -> {
            items.forEach(item ->
                    System.out.println("Updating DB: SKU " + item.getSku() + " set to " + item.getQuantity())
            );
            return items; // <--- ADD THIS: Return the data to keep the flow alive!
        };
    }
}



/*
 .handle(inventoryService(), "updateStock")
 This is the "Magic" of Spring Integration:
Input: The flow delivers a Message where the Payload is a List<InventoryItem>.
Mapping: Spring Integration looks at the bean returned by inventoryService().
Execution: It sees the method name "updateStock". It automatically extracts the List from the message payload and passes it as the items argument into your Lambda.
Completion: Your code runs, the "Database" is updated (printed), and the message moves to the next step in the flow.

Summary: Why write it like this?
Decoupling: Your InventoryService doesn't know anything about files, CSVs, or Spring Integration. It only knows how to handle a List of objects. This makes the code easy to unit test.
Conciseness: Instead of creating a whole new file InventoryServiceImpl.java with 20 lines of boilerplate code, you define the logic in 4 lines using a Lambda.
Clean Architecture: It separates the Inbound Adapter (getting the file) from the Service Activator (processing the data).

 */


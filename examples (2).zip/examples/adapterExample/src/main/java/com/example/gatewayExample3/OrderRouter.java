package com.example.gatewayExample3;

import org.springframework.stereotype.Component;

@Component
public class OrderRouter {

    public String route(String payload) {
        return payload.contains("laptop") ? "electronicsChannel" : "generalChannel";
    }
}

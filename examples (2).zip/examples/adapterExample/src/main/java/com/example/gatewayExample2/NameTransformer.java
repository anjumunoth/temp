package com.example.gatewayExample2;

import org.springframework.stereotype.Component;

@Component
public class NameTransformer {

    public String normalize(String name) {
        if (name == null || name.isBlank()) {
            return "Guest";
        }
        return Character.toUpperCase(name.charAt(0)) + name.substring(1).toLowerCase();
    }
}

package com.example.routerExampleWithAnnotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.Router;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.core.GenericTransformer;
import org.springframework.integration.router.AbstractMessageRouter;
import org.springframework.integration.router.ExpressionEvaluatingRouter;
import org.springframework.integration.router.MessageRouter;
import org.springframework.integration.router.RecipientListRouter;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

@EnableIntegration
@Configuration
public class IntegrationConfig {

    @Bean
    public MessageChannel inputChannel()
    {
        return new DirectChannel();

    }
    @Bean
    public MessageChannel normalChannel()
    {
        return new DirectChannel();

    }
    @Bean
    public MessageChannel errorChannel()
    {
        return new DirectChannel();

    }
    @Bean
    public MessageChannel warnChannel()
    {
        return new DirectChannel();

    }
    @Bean
    public MessageChannel routerChannel()
    {
        return new DirectChannel();

    }

    @Bean
    public MessageChannel auditChannel() {
        return new DirectChannel();
    }



    @Bean
    @Transformer(inputChannel = "inputChannel", outputChannel = "routerChannel")
    public GenericTransformer<String,String> uppercaseTransformer()
    {
        return  text -> text.toUpperCase();
    }

    //Router : to send to recipients based on a condition
//    @Bean
//    @Router(inputChannel = "routerChannel")
//    public MessageRouter contentRouter() {
//        return new AbstractMessageRouter() {
//            @Override
//            protected Collection<MessageChannel> determineTargetChannels(Message<?> message) {
//                String payload = (String) message.getPayload();
//                if (payload.contains("ERROR")) {
//                    return Collections.singletonList(errorChannel());
//                } else if (payload.contains("WARN")) {
//                    return Collections.singletonList(warnChannel());
//                } else {
//                    return Collections.singletonList(normalChannel());
//                }
//            }
//
//        };
//    }

// Router: use SpEL to evaluate payload and route -- Another way of implementing the above router
//    @Bean
//    @Router(inputChannel = "routerChannel")
//    public MessageRouter spelRouter() {
//        ExpressionEvaluatingRouter router =
//                new ExpressionEvaluatingRouter("payload.contains('ERROR') ? 'errorChannel' : (payload.contains('WARN') ? 'warnChannel' : 'normalChannel')");
//        router.setResolutionRequired(true); // fail if no channel resolved
//        return router;
//    }

    // Router: send to multiple channels at once
    @Bean
    @Router(inputChannel = "routerChannel")
    public MessageRouter recipientListRouter() {
        RecipientListRouter router = new RecipientListRouter();

        // Always send to auditChannel for logging
        router.addRecipient(auditChannel());

        // Conditional recipients
        router.addRecipient("errorChannel", "payload.contains('ERROR')");
        router.addRecipient("warnChannel", "payload.contains('WARN')");
        router.addRecipient("normalChannel", "!payload.contains('ERROR') && !payload.contains('WARN')");

        return router;
    }


    @Bean
    @ServiceActivator(inputChannel = "inputChannel")
    public MessageHandler errorHandler()
    {
        return message -> System.out.println("Error "+ message.getPayload());
    }
    @Bean
    @ServiceActivator(inputChannel = "warnChannel")
    public MessageHandler warnHandler() {
        return message -> System.out.println("⚠️ Warning Handler: " + message.getPayload());
    }

    @Bean
    @ServiceActivator(inputChannel = "normalChannel")
    public MessageHandler normalHandler() {
        return message -> System.out.println("✅ Normal Handler: " + message.getPayload());
    }

    @Bean
    @ServiceActivator(inputChannel = "auditChannel")
    public MessageHandler auditHandler() {
        return message -> System.out.println("📝 Audit Log: " + message.getPayload());
    }


}

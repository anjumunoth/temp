package com.example.routerExampleWithAnnotation;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;

@SpringBootApplication
public class RouterExampleAppWithAnnotation {
    public static void main(String[] args) {
        SpringApplication.run(com.example.routerExampleWithAnnotation.RouterExampleAppWithAnnotation.class, args);
    }
    @Bean
    CommandLineRunner runner(MessageChannel inputChannel)
    {
        return args -> inputChannel.send(MessageBuilder.withPayload("tthis is an WARN message").build());
    }
}

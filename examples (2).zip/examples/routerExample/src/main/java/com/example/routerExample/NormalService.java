package com.example.routerExample;

public class NormalService {
    public void handleNormal(String message)
    {
        System.out.println("Normal Handler :"+message );
    }
}

package com.example.routerExampleWithDsl;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;

@SpringBootApplication
@EnableIntegration
public class RouterExampleAppWithDsl {
    public static void main(String[] args) {
        SpringApplication.run(com.example.routerExampleWithDsl.RouterExampleAppWithDsl.class,args);

    }
    @Bean
    CommandLineRunner runner(MessageChannel inputChannel)
    {
        return args -> inputChannel.send(MessageBuilder.withPayload("tthis is an  message").build());
    }
}

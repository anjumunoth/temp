package com.example.pubSubExample;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.channel.PublishSubscribeChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;



@SpringBootApplication
@EnableIntegration
public class PubSubApp {

    public static void main(String[] args) {
        SpringApplication.run(PubSubApp.class, args);
    }

    // --- STEP 1: DEFINE THE PUBLISH-SUBSCRIBE CHANNEL ---
    @Bean
    public MessageChannel newsChannel() {
        // This is the special pipe.
        // Unlike a standard DirectChannel, this sends to EVERYONE listening.
        return new PublishSubscribeChannel();
    }

    // --- STEP 2: DEFINE SUBSCRIBER 1 (EMAIL) ---
    @Bean
    public IntegrationFlow emailFlow() {
        return IntegrationFlow.from("newsChannel")
                .handle(message -> {
                    System.out.println("[EMAIL SERVICE] Sending email with content: " + message.getPayload());
                })
                .get();
    }

    // --- STEP 3: DEFINE SUBSCRIBER 2 (SMS) ---
    @Bean
    public IntegrationFlow smsFlow() {
        return IntegrationFlow.from("newsChannel")
                .handle(message -> {
                    System.out.println("[SMS SERVICE] Sending SMS with content: " + message.getPayload());
                })
                .get();
    }

    // --- STEP 4: A TESTER TO RUN IT ---
    @Bean
    public CommandLineRunner runner(MessageChannel newsChannel) {
        return args -> {
            String news = "Breaking News: Spring Integration is awesome!";

            System.out.println("Publishing news to the channel...");

            // We wrap our data into a 'Message' and send it to the channel
            newsChannel.send(MessageBuilder.withPayload(news).build());
        };
    }
}

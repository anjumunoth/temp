package com.example.routerExampleWithDsl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.dsl.IntegrationFlow;

import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;

@EnableIntegration
@Configuration
public class IntegrationConfigWithDsl {
    @Bean
    public IntegrationFlow multiRouteFlow() {
        return IntegrationFlow.from("inputChannel")
                // Transformer: convert payload to uppercase
                .transform(String.class, String::toUpperCase)

                // Recipient List Router
                .routeToRecipients(r -> r
                        // Always send to auditChannel
                        .recipient("auditChannel")
                        .recipient("errorChannel", payload -> payload.toString().contains("ERROR"))
                        .recipient("warnChannel", payload -> payload.toString().contains("WARN"))
                        .recipient("normalChannel",
                                payload -> !payload.toString().contains("ERROR")
                                        && !payload.toString().contains("WARN"))

                )
                .get();
    }

    // Channels
    @Bean
    public MessageChannel inputChannel() { return new DirectChannel(); }
    @Bean public MessageChannel errorChannel() { return new DirectChannel(); }
    @Bean public MessageChannel warnChannel() { return new DirectChannel(); }
    @Bean public MessageChannel normalChannel() { return new DirectChannel(); }
    @Bean public MessageChannel auditChannel() { return new DirectChannel(); }

    @Bean
    public IntegrationFlow errorHandlerFlow() {
        return IntegrationFlow.from("errorChannel")
                .handle(m -> System.out.println("❌ Error Handler: " + m.getPayload()))
                .get();

    }

    @Bean
    public IntegrationFlow warnHandlerFlow() {
        return IntegrationFlow.from("warnChannel")
                .handle(m -> System.out.println("⚠️ Warning Handler: " + m.getPayload()))
                .get();
    }

    @Bean
    public IntegrationFlow normalHandlerFlow() {
        return IntegrationFlow.from("normalChannel")
                .handle(m -> System.out.println("✅ Normal Handler: " + m.getPayload()))
                .get();
    }

    @Bean
    public IntegrationFlow auditHandlerFlow() {
        return IntegrationFlow.from("auditChannel")
                .handle(m -> System.out.println("📝 Audit Log: " + m.getPayload()))
                .get();
    }



}

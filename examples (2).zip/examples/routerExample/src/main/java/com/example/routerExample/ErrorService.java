package com.example.routerExample;

public class ErrorService {
    public void handleError(String message)
    {
        System.out.println("Error Handler :"+message );
    }
}

package com.example.routerExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RouterExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}

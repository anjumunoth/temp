package com.example.secondExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecondExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}

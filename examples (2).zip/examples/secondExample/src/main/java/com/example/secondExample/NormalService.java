package com.example.secondExample;

public class NormalService {
    public void handleNormal(String message)
    {
        System.out.println("Normal Handler :"+message );
    }
}

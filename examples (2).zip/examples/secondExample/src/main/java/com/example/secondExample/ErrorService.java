package com.example.secondExample;

public class ErrorService {
    public void handleError(String message)
    {
        System.out.println("Error Handler :"+message );
    }
}

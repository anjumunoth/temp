package com.example.secondExample;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;

@SpringBootApplication
@ImportResource("classpath:integration-context.xml")
public class SecondExampleApplication {

	@Autowired
	private MessageChannel inputChannel;

	public static void main(String[] args) {
		SpringApplication.run(SecondExampleApplication.class, args);
	}
	@Bean
	CommandLineRunner runner()
	{
		return args -> inputChannel.send(MessageBuilder.withPayload("RouterExampleWithSpringAndXml").build());
	}
}

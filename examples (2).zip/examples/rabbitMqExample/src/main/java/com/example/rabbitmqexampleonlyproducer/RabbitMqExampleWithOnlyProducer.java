package com.example.rabbitmqexampleonlyproducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitMqExampleWithOnlyProducer {
    public static void main(String[] args) {
        SpringApplication.run(RabbitMqExampleWithOnlyProducer.class, args);
    }

}

/*
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>

    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-integration</artifactId>
    </dependency>

    <dependency>
        <groupId>org.springframework.integration</groupId>
        <artifactId>spring-integration-amqp</artifactId>
    </dependency>

    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-amqp</artifactId>
    </dependency>
</dependencies>

Client -> REST Controller -> Spring Integration Gateway -> Channel -> RabbitMQ

What this example does
exposes a REST endpoint: POST /orders
receives JSON order data
sends it into a Spring Integration flow
publishes the message to a RabbitMQ exchange


What happens internally

When you call the REST API:

controller receives JSON
controller calls orderGateway.sendOrder(...)
gateway sends message to ordersInputChannel
integration flow picks it up
AMQP outbound adapter publishes it to RabbitMQ exchange
RabbitMQ routes it to orders.queue


*
Run: for starting rabbitmq

docker compose up -d

RabbitMQ UI:

http://localhost:15672

Login:

guest / guest
 */






package com.example.rabbitMqExample;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;



@Service
public class OrderConsumer {

    @RabbitListener(queues = "orders.queue")
    public void consume(OrderEvent event) {
        System.out.println("Received from RabbitMQ: " + event.getOrderId()
                + ", customer=" + event.getCustomerName()
                + ", amount=" + event.getAmount()
                + ", status=" + event.getStatus()
                + ", source=" + event.getSource());
    }
}




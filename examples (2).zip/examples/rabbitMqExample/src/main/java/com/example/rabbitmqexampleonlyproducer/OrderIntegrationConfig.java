package com.example.rabbitmqexampleonlyproducer;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.amqp.dsl.Amqp;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.messaging.MessageChannel;

@Configuration
public class OrderIntegrationConfig {

    @Bean
    public MessageChannel ordersInputChannel() {
        return new DirectChannel();
    }

    @Bean
    public IntegrationFlow orderToRabbitFlow(RabbitTemplate rabbitTemplate) {
        return IntegrationFlow
                .from(ordersInputChannel())
                .handle(Amqp.outboundAdapter(rabbitTemplate)
                        .exchangeName("orders.exchange")
                        .routingKey("orders.created"))
                .get();
    }
}





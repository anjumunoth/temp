package com.example.rabbitmqexampleonlyproducer;


import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.messaging.handler.annotation.Header;


@MessagingGateway
public interface OrderGateway {

    @Gateway(requestChannel = "ordersInputChannel")
    void sendOrder(OrderRequest orderRequest,
                   @Header("eventType") String eventType);
}

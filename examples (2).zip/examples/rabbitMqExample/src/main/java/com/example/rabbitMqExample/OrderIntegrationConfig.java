package com.example.rabbitMqExample;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.amqp.dsl.Amqp;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.messaging.MessageChannel;



@Configuration
public class OrderIntegrationConfig {

    @Bean
    public MessageChannel ordersInputChannel() {
        return new DirectChannel();
    }

    @Bean
    public MessageChannel orderErrorChannel() {
        return new DirectChannel();
    }

    @Bean
    public IntegrationFlow orderToRabbitFlow(RabbitTemplate rabbitTemplate) {
        return IntegrationFlow
                .from("ordersInputChannel")
                .log(message -> "Received order request: " + message.getPayload())
                .<OrderRequest, OrderEvent>transform(request -> {
                    if (request.getAmount() == null || request.getAmount() <= 0) {
                        throw new IllegalArgumentException("Invalid amount");
                    }

                    return new OrderEvent(
                            request.getOrderId(),
                            request.getCustomerName(),
                            request.getAmount(),
                            "CREATED",
                            "order-service"
                    );
                })
                .log(message -> "Transformed order event: " + message.getPayload())
                .handle(Amqp.outboundAdapter(rabbitTemplate)
                        .exchangeName(RabbitConfig.EXCHANGE)
                        .routingKey(RabbitConfig.ROUTING_KEY))
                .get();
    }
}




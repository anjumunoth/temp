package com.example.transactionWithDbPersistence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionWithDbPersistenceApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.transactionWithDbPersistence;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;

@MessagingGateway
public interface OrderGateway {

    @Gateway(requestChannel = "orderInputChannel", replyTimeout = 5000)
    OrderResponse process(OrderRequest request);
}
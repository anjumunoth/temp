package com.example.transactionWithDbPersistence;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;

@Configuration
public class IntegrationConfig {

    @Bean
    public IntegrationFlow orderFlow(OrderTransformer transformer, OrderRouter router) {
        return IntegrationFlow.from("orderInputChannel")
                .transform(transformer, "normalize")
                .filter(OrderRequest.class,
                        request -> request.getItem() != null
                                && !request.getItem().isBlank()
                                && request.getQuantity() > 0,
                        spec -> spec.throwExceptionOnRejection(true))
                .route(router, "route")
                .get();
    }

    @Bean
    public IntegrationFlow electronicsFlow(OrderService orderService) {
        return IntegrationFlow.from("electronicsChannel")
                .handle(orderService, "processElectronicsOrder")
                .get();
    }

    @Bean
    public IntegrationFlow generalFlow(OrderTransactionalService orderTransactionalService) {
        return IntegrationFlow.from("generalChannel")
                .handle(orderTransactionalService, "process")
                .get();
    }



}

package com.example.transactionWithDbPersistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionWithDbPersistenceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionWithDbPersistenceApplication.class, args);
	}

}

/*
GET http://localhost:8080/debug/orders -- tO VIEW data in orders table

POST /orders
1. // Will fail and rollback in db
{
    "item":"FAIL",
    "quantity":5

}

2. // will be successful and stored in db
{
    "item":"ipad",
    "quantity":5

}

<!--  JPA -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>

        <!-- H2 DB -->
        <dependency>
            <groupId>com.h2database</groupId>
            <artifactId>h2</artifactId>
            <scope>runtime</scope>
        </dependency>


 */

package com.example.transactionWithDbPersistence;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Random;

@Service
public class OrderTransactionalService {

    private final OrderRepository repository;

    public OrderTransactionalService(OrderRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public void process(OrderRequest request) {
        System.out.println("➡️ Transaction START");
        Random random = new Random();
        long randomLong = random.nextLong();
        Order order=new Order(randomLong,request.getItem());
        repository.save(order);

        // Simulate failure
        if ("FAIL".equalsIgnoreCase(order.getProduct())) {
            System.out.println("❌ Simulating failure...");
            throw new RuntimeException("Simulated Exception");
        }

        System.out.println("✅ Transaction COMMIT");
    }
}
